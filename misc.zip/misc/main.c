//Rising and falling edge interrupts work but the timestamp intr doesn't
#include "myip_intr_only.h"
#include "stdio.h"
#include "xil_io.h"
#include "xintc_l.h"
#include "xparameters.h"
#define MYIP_BASEADDR 0x44a20000
volatile int count = 0;
volatile u32 data;
void handler()
{
   count++;
   xil_printf("interrupt %d \n\r", count);
//   data = MYIP_INTR_ONLY_mReadReg(MYIP_BASEADDR, 28);
   MYIP_INTR_ONLY_mWriteReg(MYIP_BASEADDR, 0xc,0x7);//ack
//   sleep(1);
//   data = MYIP_INTR_ONLY_mReadReg(MYIP_BASEADDR, 0);
//   sleep(1);
//   data = MYIP_INTR_ONLY_mReadReg(MYIP_BASEADDR, 4);
//   sleep(1);
//   data = MYIP_INTR_ONLY_mReadReg(MYIP_BASEADDR, 8);
//   sleep(1);
//   data = MYIP_INTR_ONLY_mReadReg(MYIP_BASEADDR, 12);
//   sleep(1);
//   data = MYIP_INTR_ONLY_mReadReg(MYIP_BASEADDR, 16);
//   sleep(1);
//   data = MYIP_INTR_ONLY_mReadReg(MYIP_BASEADDR, 20);
//   sleep(1);
//   data = MYIP_INTR_ONLY_mReadReg(MYIP_BASEADDR, 24);
//   sleep(1);
//   data = MYIP_INTR_ONLY_mReadReg(MYIP_BASEADDR, 28);




}
int main()
{
   microblaze_enable_interrupts();

   XIntc_RegisterHandler(XPAR_INTC_SINGLE_BASEADDR,XPAR_INTC_0_MYIP_INTR_ONLY_0_VEC_ID,
   (XInterruptHandler)handler, XPAR_INTC_SINGLE_BASEADDR);

   XIntc_MasterEnable(XPAR_INTC_SINGLE_BASEADDR);

   XIntc_EnableIntr(XPAR_INTC_SINGLE_BASEADDR, XPAR_MYIP_INTR_ONLY_0_IRQ_MASK);

   /*
    * Enable all interrupt source from user logic.
    */
   MYIP_INTR_ONLY_mWriteReg(MYIP_BASEADDR, 4, 0x7);
   /*
    * Set global interrupt enable.
    */
   MYIP_INTR_ONLY_mWriteReg(MYIP_BASEADDR, 0, 0x1);
   xil_printf("Wait for Interrupts.... \n\r");
   while(count<3);
   MYIP_INTR_ONLY_mWriteReg(MYIP_BASEADDR, 24,0x1);
   while(1);
   return 0;
}

